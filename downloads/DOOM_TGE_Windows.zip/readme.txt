#############  ############## ###################### ########
##          #####           ###           ####     ###     ##
##   ####    ###    ####    ###    ####    ###      #      ##
##   ####    ###    ####    ###    ####    ###             ##
##   ####    ###    ####    ###    ####    ###   #         ##
##   ####    ###    ####    ###    ####    ###   ##        ##
##   ####    ###    ####    ###    ####    ###   ##    #   ##
##   ####    ###    ####    ###    ####    ###   ##   ##   ##
##   ###     ###     ###   #####   ###     ###   ###  ##   ##
##           #####        #######        #####   ###  ##   ##
##          ################# ##########################   ##
##      ####################   #########################   ##
##   ##########                               ##########   ##
## ########                 THE                   ######## ##
#########                                           #########
######               GALLERY  EXPERIENCE               ######


            CREATED BY FILIPPO MEOZZI & LIAM STONE
			           SCUM DOG GAMES
                      https://scum.dog/

			 DOOM is copyright © 1993 id Software

NOTES #######################################################

Thank you for downloading DOOM: The Gallery Experience! This
is the standalone version, and functions a little differently
than the web version in terms of storage and saving.

Your save data can be found in the following location:
<user>/AppData/Local/SCUMDOG/doom_tge

Similarly, the game's embedded web browser can be found here:
<user>/AppData/Local/DOOM The Gallery Experience

If you wish to uninstall the game, you can delete your
executable file and both of these directories without any
issues. Doing so will clear your save data--be warned!

If you are running into issues with capturing the game window
with OBS, try switching the Capture Method to "Windows 10".

LINKS #######################################################

OUR WEBSITE
https://scum.dog/games/doom_tge

NEWGROUNDS
https://www.newgrounds.com/portal/view/960452

ITCH.IO
https://bobatealee.itch.io/doom-the-gallery-experience

SOURCE CODE
https://github.com/bobatealee/doom_tge